# KantoDex Pro

Wypasiony, responsywny Pokédex w czystym HTML/CSS/JS.

## Funkcje
- ciemny motyw + przełącznik jasnego,
- Pokémony #001–#1025,
- wyszukiwarka,
- filtrowanie po typie i regionie,
- sortowanie po numerze, nazwie i sumie statystyk,
- szczegółowe statystyki,
- łańcuchy ewolucji,
- ulubione zapisujące się w `localStorage`,
- zakładka regionów,
- responsywny interfejs.

Dane są pobierane z PokéAPI. API udostępnia m.in. Pokémony, typy, regiony, gatunki i łańcuchy ewolucji. 
