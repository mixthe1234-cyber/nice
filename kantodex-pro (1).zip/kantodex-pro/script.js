const API="https://pokeapi.co/api/v2";
const els={grid:document.querySelector("#grid"),favGrid:document.querySelector("#favGrid"),search:document.querySelector("#search"),type:document.querySelector("#type"),region:document.querySelector("#region"),sort:document.querySelector("#sort"),count:document.querySelector("#resultCount"),favCount:document.querySelector("#favCount"),modal:document.querySelector("#modal"),detail:document.querySelector("#detail")};
let all=[], favorites=JSON.parse(localStorage.getItem("kantodex-favorites")||"[]");

const regions=[
 ["Kanto","gen-i","#001–151","Pokémony pierwszej generacji. Dom dla starterów, Eevee, Mewtwo i wielu klasyków."],
 ["Johto","gen-ii","#152–251","Region drugiej generacji, połączony geograficznie z Kanto."],
 ["Hoenn","gen-iii","#252–386","Region pełen wysp, oceanów i Pokémonów trzeciej generacji."],
 ["Sinnoh","gen-iv","#387–493","Górzysty region z czwartą generacją."],
 ["Unova","gen-v","#494–649","Region piątej generacji inspirowany wschodnim wybrzeżem USA."],
 ["Kalos","gen-vi","#650–721","Region szóstej generacji znany m.in. z Mega Ewolucji."],
 ["Alola","gen-vii","#722–809","Wyspiarski region z formami regionalnymi."],
 ["Galar","gen-viii","#810–905","Region ósmej generacji z Dynamaxem."],
 ["Paldea","gen-ix","#906–1025","Region dziewiątej generacji i Terastalizacji."]
];
const names={normal:"Normalny",fire:"Ogień",water:"Woda",electric:"Elektryczny",grass:"Trawa",ice:"Lód",fighting:"Walka",poison:"Trucizna",ground:"Ziemia",flying:"Latanie",psychic:"Psychiczny",bug:"Robak",rock:"Skała",ghost:"Duch",dragon:"Smok",dark:"Mrok",steel:"Stal",fairy:"Wróżka"};
const statNames={hp:"HP",attack:"Atak",defense:"Obrona","special-attack":"Sp. Atak","special-defense":"Sp. Obrona",speed:"Szybkość"};

function cap(s){return s[0].toUpperCase()+s.slice(1)}
function badge(t){return `<span class="badge ${t}">${names[t]||cap(t)}</span>`}
function isFav(id){return favorites.includes(id)}
function saveFav(){localStorage.setItem("kantodex-favorites",JSON.stringify(favorites));els.favCount.textContent=favorites.length}
function card(p){
 return `<article class="card" data-id="${p.id}">
 <div class="cardtop">#${String(p.id).padStart(4,"0")}</div>
 <button class="star ${isFav(p.id)?"on":""}" data-star="${p.id}" title="Ulubione">${isFav(p.id)?"★":"☆"}</button>
 <img class="sprite" src="${p.sprites.other["official-artwork"].front_default}" alt="${cap(p.name)}" loading="lazy">
 <h3 class="name">${p.name}</h3><div class="badges">${p.types.map(x=>badge(x.type.name)).join("")}</div></article>`
}
function filterList(list=all){
 const q=els.search.value.toLowerCase().trim(), typ=els.type.value, reg=els.region.value;
 let a=list.filter(p=>(!q||p.name.includes(q)||String(p.id).includes(q))&&(typ==="all"||p.types.some(x=>x.type.name===typ))&&(reg==="all"||p.generation===reg));
 if(els.sort.value==="name")a.sort((x,y)=>x.name.localeCompare(y.name)); if(els.sort.value==="base")a.sort((x,y)=>y.total-x.total); else if(els.sort.value==="id")a.sort((x,y)=>x.id-y.id);
 return a;
}
function render(){
 const a=filterList();els.count.textContent=`${a.length} Pokémonów`;els.grid.innerHTML=a.map(card).join("");
}
function renderFav(){
 const a=all.filter(p=>isFav(p.id));document.querySelector("#emptyFav").classList.toggle("hidden",a.length>0);els.favGrid.innerHTML=a.map(card).join("");
}
async function details(p){
 if(!p.species){p.species=await (await fetch(`${API}/pokemon-species/${p.id}`)).json()}
 let chain;
 try{chain=await (await fetch(p.species.evolution_chain.url)).json()}catch{}
 const text=p.species.flavor_text_entries?.find(x=>x.language.name==="en")?.flavor_text?.replace(/[\n\f]/g," ")||"Brak opisu.";
 const total=p.total;
 els.detail.innerHTML=`<div class="detail-head">
 <img class="detail-img" src="${p.sprites.other["official-artwork"].front_default}" alt="${p.name}">
 <div><div class="detail-num">#${String(p.id).padStart(4,"0")} · ${p.generation.replace("gen-","GEN ")}</div>
 <h2 class="detail-name">${p.name}</h2><div class="badges">${p.types.map(x=>badge(x.type.name)).join("")}</div>
 <p class="desc">${text}</p><p class="desc"><b>Wysokość:</b> ${(p.height/10).toFixed(1)} m · <b>Waga:</b> ${(p.weight/10).toFixed(1)} kg</p></div></div>
 <div class="stats">${p.stats.map(s=>`<div class="stat"><span>${statNames[s.stat.name]||s.stat.name}</span><span class="bar"><i style="width:${Math.min(100,s.base_stat/2.55)}%"></i></span><b>${s.base_stat}</b></div>`).join("")}</div>
 <div class="evo"><h3>ŁAŃCUCH EWOLUCJI</h3><div id="evoRow" class="evo-row">${chain?await evoHTML(chain.chain):"<span class='desc'>Brak danych.</span>"}</div></div>`;
 els.modal.classList.remove("hidden");document.body.style.overflow="hidden";
}
async function evoHTML(node){
 let out=`<div class="evo-p"><img src="https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${node.species.url.match(/(\d+)\/$/)[1]}.png"><small>${node.species.name}</small></div>`;
 if(node.evolves_to?.length){for(const n of node.evolves_to){out+=`<span class="arrow">→</span>`+await evoHTML(n)}}
 return out
}
function close(){els.modal.classList.add("hidden");document.body.style.overflow=""}
function renderRegions(){document.querySelector("#regionCards").innerHTML=regions.map(r=>`<article class="region"><h3>${r[0]}</h3><p><b>${r[2]}</b></p><p>${r[3]}</p></article>`).join("")}

async function load(){
 const res=await fetch(`${API}/pokemon?limit=1025`), data=await res.json();
 all=await Promise.all(data.results.map(async x=>{const p=await (await fetch(x.url)).json();p.generation=genFor(p.id);p.total=p.stats.reduce((s,x)=>s+x.base_stat,0);return p}));
 const types=[...new Set(all.flatMap(p=>p.types.map(t=>t.type.name)))].sort();
 els.type.innerHTML=`<option value="all">Wszystkie typy</option>`+types.map(t=>`<option value="${t}">${names[t]||cap(t)}</option>`).join("");
 els.region.innerHTML=`<option value="all">Wszystkie regiony</option>`+regions.map(r=>`<option value="${r[1]}">${r[0]}</option>`).join("");
 saveFav();render();renderRegions();
}
function genFor(id){if(id<=151)return"gen-i";if(id<=251)return"gen-ii";if(id<=386)return"gen-iii";if(id<=493)return"gen-iv";if(id<=649)return"gen-v";if(id<=721)return"gen-vi";if(id<=809)return"gen-vii";if(id<=905)return"gen-viii";return"gen-ix"}

[els.search,els.type,els.region,els.sort].forEach(x=>x.addEventListener("input",render));document.querySelector("#clear").onclick=()=>{els.search.value="";els.type.value="all";els.region.value="all";els.sort.value="id";render()};
document.querySelectorAll(".nav").forEach(n=>n.onclick=()=>{document.querySelectorAll(".nav").forEach(x=>x.classList.remove("active"));n.classList.add("active");["pokedex","favorites","regions"].forEach(v=>document.querySelector("#"+v+"View").classList.add("hidden"));document.querySelector("#"+n.dataset.view+"View").classList.remove("hidden");document.querySelector("#pageTitle").textContent=n.dataset.view==="pokedex"?"Pokémony":n.dataset.view==="favorites"?"Ulubione":"Regiony";if(n.dataset.view==="favorites")renderFav()});
document.addEventListener("click",async e=>{const s=e.target.closest("[data-star]");if(s){e.stopPropagation();const id=+s.dataset.star;favorites=isFav(id)?favorites.filter(x=>x!==id):[...favorites,id];saveFav();render();renderFav();return}const c=e.target.closest(".card");if(c){const p=all.find(x=>x.id===+c.dataset.id);if(p)await details(p)}if(e.target.matches("[data-close]"))close()});
document.querySelector("#theme").onclick=()=>document.body.classList.toggle("light");
document.addEventListener("keydown",e=>{if(e.key==="Escape")close()});
load().catch(e=>{els.count.textContent="Błąd ładowania danych. Odśwież stronę.";console.error(e)});
